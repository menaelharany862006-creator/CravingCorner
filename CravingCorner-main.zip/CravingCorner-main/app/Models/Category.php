<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'type', 'description', 'image'];

    public function foodItems()
    {
        return $this->hasMany(FoodItem::class);
    }

    public function beverages()
    {
        return $this->hasMany(Beverage::class);
    }
}
